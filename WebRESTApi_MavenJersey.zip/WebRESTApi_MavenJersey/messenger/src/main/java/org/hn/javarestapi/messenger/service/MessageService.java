package org.hn.javarestapi.messenger.service;

import java.util.ArrayList;
import java.util.List;

import org.hn.javarestapi.messenger.model.Message;

public class MessageService {

	
	public List<Message> getAllMessages(){
		Message m1 = new Message(1L, "kdjfer");
		Message m2 = new Message(2L, "iuer");
		List<Message> list = new ArrayList<>();
		list.add(m1);
		list.add(m2);
		return list;
	}
	
	public Message getMessage(long id){
		Message m1 = new Message(1L, "kdjfer");		
		return m1;
	}
	
	public Message addMessage(Message m){
		Message m1 = new Message(1L, "kdjfer");		
		return m1;
	}
	
	public Message updateMessage(Message m){
		Message m1 = new Message(1L, "kdjfer");		
		return m1;
	}
	
	public Message removeMessage(long id){
		Message m1 = new Message(1L, "kdjfer");		
		return m1;
	}
}
